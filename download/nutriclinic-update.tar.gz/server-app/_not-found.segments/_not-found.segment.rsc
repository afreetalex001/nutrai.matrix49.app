1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/800d52d72d19873a.js","/_next/static/chunks/202b956bc838ef27.js","/_next/static/chunks/453d3f9dc65064f5.js"],"default"]
3:I[37457,["/_next/static/chunks/800d52d72d19873a.js","/_next/static/chunks/202b956bc838ef27.js","/_next/static/chunks/453d3f9dc65064f5.js"],"default"]
0:{"buildId":"NoS4f0hRic4BC5tC0fuKv","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}

:HL["/_next/static/chunks/a7d5d0791c8c6223.css","style"]
:HL["/_next/static/chunks/ecf50543edf0e970.css","style"]
0:{"buildId":"NoS4f0hRic4BC5tC0fuKv","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"/_not-found","paramType":null,"paramKey":"/_not-found","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}

var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/users/route.js")
R.c("server/chunks/[root-of-the-server]__4f45498c._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/[root-of-the-server]__b6e1f23e._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_users_route_actions_595e9dd9.js")
R.m(66129)
module.exports=R.m(66129).exports

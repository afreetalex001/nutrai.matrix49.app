var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/users/[id]/activate/route.js")
R.c("server/chunks/[root-of-the-server]__bafbf154._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/[root-of-the-server]__b6e1f23e._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_users_[id]_activate_route_actions_8ed30494.js")
R.m(44476)
module.exports=R.m(44476).exports

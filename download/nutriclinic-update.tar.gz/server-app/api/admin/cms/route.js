var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/cms/route.js")
R.c("server/chunks/[root-of-the-server]__d8ef6b84._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/[root-of-the-server]__b6e1f23e._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_cms_route_actions_3a9e5d78.js")
R.m(30387)
module.exports=R.m(30387).exports

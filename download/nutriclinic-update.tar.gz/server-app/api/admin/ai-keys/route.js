var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/ai-keys/route.js")
R.c("server/chunks/[root-of-the-server]__28d8aa7d._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/[root-of-the-server]__b6e1f23e._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_ai-keys_route_actions_793bd7dd.js")
R.m(55284)
module.exports=R.m(55284).exports

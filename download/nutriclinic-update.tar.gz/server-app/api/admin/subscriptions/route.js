var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/subscriptions/route.js")
R.c("server/chunks/[root-of-the-server]__a4287f38._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/[root-of-the-server]__b6e1f23e._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_subscriptions_route_actions_86fc36f4.js")
R.m(50456)
module.exports=R.m(50456).exports

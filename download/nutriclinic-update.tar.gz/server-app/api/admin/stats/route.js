var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/stats/route.js")
R.c("server/chunks/[root-of-the-server]__d38ce1aa._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/[root-of-the-server]__b6e1f23e._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_stats_route_actions_05832952.js")
R.m(2068)
module.exports=R.m(2068).exports

var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/ai-providers/route.js")
R.c("server/chunks/[root-of-the-server]__6c3f9519._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/[root-of-the-server]__b6e1f23e._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_ai-providers_route_actions_67630b1f.js")
R.m(4836)
module.exports=R.m(4836).exports

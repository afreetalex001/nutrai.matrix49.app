var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/seed/route.js")
R.c("server/chunks/[root-of-the-server]__97c08fa5._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/[root-of-the-server]__b6e1f23e._.js")
R.c("server/chunks/_next-internal_server_app_api_seed_route_actions_926844ce.js")
R.m(44766)
module.exports=R.m(44766).exports

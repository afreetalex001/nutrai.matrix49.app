var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/patients/[id]/macros/route.js")
R.c("server/chunks/[root-of-the-server]__1c0d5697._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/[root-of-the-server]__b6e1f23e._.js")
R.c("server/chunks/_next-internal_server_app_api_patients_[id]_macros_route_actions_edf05ad0.js")
R.m(17904)
module.exports=R.m(17904).exports

var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/patients/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__2c22c1ee._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/[root-of-the-server]__b6e1f23e._.js")
R.c("server/chunks/_next-internal_server_app_api_patients_[id]_route_actions_f059dbb3.js")
R.m(75800)
module.exports=R.m(75800).exports

var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/visits/route.js")
R.c("server/chunks/[root-of-the-server]__fdf54b96._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/[root-of-the-server]__b6e1f23e._.js")
R.c("server/chunks/_next-internal_server_app_api_visits_route_actions_d31ccbd2.js")
R.m(85650)
module.exports=R.m(85650).exports

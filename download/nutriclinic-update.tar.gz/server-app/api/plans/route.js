var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/plans/route.js")
R.c("server/chunks/[externals]__901956e1._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/[root-of-the-server]__c7044fba._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_next-internal_server_app_api_plans_route_actions_1022e78e.js")
R.m(81872)
module.exports=R.m(81872).exports

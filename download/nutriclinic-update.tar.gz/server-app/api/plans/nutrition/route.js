var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/plans/nutrition/route.js")
R.c("server/chunks/[root-of-the-server]__30613487._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/[root-of-the-server]__b6e1f23e._.js")
R.c("server/chunks/_next-internal_server_app_api_plans_nutrition_route_actions_d89b10d6.js")
R.m(20100)
module.exports=R.m(20100).exports

var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/plans/exercise/route.js")
R.c("server/chunks/[root-of-the-server]__d7f35c2e._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/[root-of-the-server]__b6e1f23e._.js")
R.c("server/chunks/_next-internal_server_app_api_plans_exercise_route_actions_be929494.js")
R.m(93752)
module.exports=R.m(93752).exports

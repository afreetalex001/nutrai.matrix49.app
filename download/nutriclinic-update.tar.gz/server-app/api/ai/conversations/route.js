var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/ai/conversations/route.js")
R.c("server/chunks/[root-of-the-server]__146c80de._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/[root-of-the-server]__b6e1f23e._.js")
R.c("server/chunks/_next-internal_server_app_api_ai_conversations_route_actions_92cfecef.js")
R.m(718)
module.exports=R.m(718).exports

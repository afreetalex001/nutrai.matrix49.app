var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/ai/chat/route.js")
R.c("server/chunks/[root-of-the-server]__6f9b7f37._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/[root-of-the-server]__b6e1f23e._.js")
R.c("server/chunks/_next-internal_server_app_api_ai_chat_route_actions_43cdb436.js")
R.m(23316)
module.exports=R.m(23316).exports

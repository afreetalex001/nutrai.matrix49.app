module.exports=[34152,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_patients_%5Bid%5D_macros_route_actions_edf05ad0.js.map
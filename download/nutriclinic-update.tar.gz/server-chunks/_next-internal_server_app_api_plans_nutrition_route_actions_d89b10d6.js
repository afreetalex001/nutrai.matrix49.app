module.exports=[86615,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_plans_nutrition_route_actions_d89b10d6.js.map
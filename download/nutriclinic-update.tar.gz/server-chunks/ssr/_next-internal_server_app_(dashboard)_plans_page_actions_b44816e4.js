module.exports=[28910,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_plans_page_actions_b44816e4.js.map
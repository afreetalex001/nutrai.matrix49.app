module.exports=[92395,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_admin_cms_page_actions_f27c1a18.js.map
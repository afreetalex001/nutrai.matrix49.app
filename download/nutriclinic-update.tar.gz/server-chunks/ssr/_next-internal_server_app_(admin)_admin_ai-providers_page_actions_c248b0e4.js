module.exports=[82474,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_admin_ai-providers_page_actions_c248b0e4.js.map
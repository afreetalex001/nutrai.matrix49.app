module.exports=[94257,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_patients_new_page_actions_ac72e15f.js.map
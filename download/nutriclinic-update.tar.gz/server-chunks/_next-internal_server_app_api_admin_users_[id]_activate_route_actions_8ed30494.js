module.exports=[50003,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_users_%5Bid%5D_activate_route_actions_8ed30494.js.map
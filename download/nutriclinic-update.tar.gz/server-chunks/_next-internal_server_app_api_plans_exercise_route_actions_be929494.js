module.exports=[57034,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_plans_exercise_route_actions_be929494.js.map